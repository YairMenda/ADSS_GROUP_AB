Welcome to STORAGE SYSTEM!

With this project u can easily manage a full system of storages or stores.

When u run PresentationLayer\main.java u will be exposed to our functions menu.
The choices will be made by integers number at the menu and go on with specific inputs described on each case u choose.
Any wrong input will be loop u to write an input again.

We also provide u an initial data to work with:

Storages: A          Categories: Snacks         Sub-Categories: Snacks - Chocolates		Products : Chocolates - Milk Chocolate
	  		         Drinks				Snacks - Salties			   Chocolates - Dark Chocolate
	    		         Pharmacy			Drinks - Alchohol                          Chocolates - White Chocolate
	                         Toys				Drinks - Soft-Drinks			   Salties - Salted Chips
								Pharmacy - Shower		           Salties - Pretzels
								Pharmacy - Pills			   Salties - Popcorn
								Toys - Lego				   Soft-Drinks - Beer
													   Soft-Drinks - Wine
													   Soft-Drinks - Whiskey
													   Shower - Coke
													   Shower- Sprite
													   Shower - Fanta
													   Pills - Shampoo
													   Pills - Body Wash
													   Pills - Conditioner
													   Lego - Lego City
													   Lego - Lego Friends
													   Lego - Lego Technic

Every products also have some items, some of them are expired and the rest are still standing the dates.

Feel free to use the initial data and enjoy using our system!
	